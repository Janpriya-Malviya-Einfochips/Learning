
#include <stdio.h>
#include <stdint.h>
#include "TestSerialEndPoint.h"
#include "CommandMngr.h"
#include <string.h>
DeviceStatus_st TestDataSet = 
{
	.u32CurrentPick = 100,
	.u32DesignLength = 200,
	.u16CurrentRepeat = 300,
	.u16Speed = 400,
	.u32Second = 500,
	.fCurrentProduction = 600.999,
	.u16TotalProduction = 700,
	.u8TaskNumber= 80,
	.u8MachineType= 90,
	.u16TotalRepeat= 1000,
	.u16BorderRepeat= 1100,
	.u32BorderPick= 1200,
	.u32BorderLength= 1300,
	.u8FileName1 = { 'J' , 'A' , 'N' , '\0' },
	.u8FileName2 = { 'J' , 'A' , 'N' , '2', '\0' },
};

#define BUFF_MAX 1024
BOOL isTestDone = 0;
uint8_t Buffer[BUFF_MAX] = {0};


BOOL SendToSerial( void* args , EncodePacket_t encodeCb )
{
	printf("Send TO SERIAL \n");
	return FALSE;
}

static EndPoint_t SerialEndPoint = 
{
	.mType 		= SERIAL,
	.mIsEnabled = TRUE,
	.Send       = &SendToSerial,
};


void Serial_Init()
{
	RegisterEndPoint(&SerialEndPoint);
}

BOOL IsSerialTestDone()
{
	return isTestDone;
}

void StartSerialTest()
{
	isTestDone  = 0;
}


void ProcSerialEndPoint()
{
	Cmd  TestCmd;
	if(!isTestDone)
	{
		isTestDone = 1;
		//Copy buffer 
		memcpy( &Buffer[0] , (void*)( &TestDataSet) , sizeof(TestDataSet) );

		if( !IsValidCommandusingIChar( SERIAL , 'A' , &TestCmd ) ) 
		{
			printf("Command Invalid Test Done \n");
			return;
		}
		printf("Command Validated !!! %zu  \n",GetCommandLength( &TestCmd ));

		if( !ParseSerialCommand( &Buffer[0] , sizeof(TestDataSet) , &TestCmd ))
		{
			printf("Parsnig Failed  !!!\n" );
			return;
		}

		//Handle Command Now 
		printf("Parsing Done !!! \n");
		DumpDeviceStatus(&TestCmd.mData.mDeviceStatus);
		printf("HandleCommand Done !!! %d \n",ProcessCommand(&TestCmd ));
	}
}