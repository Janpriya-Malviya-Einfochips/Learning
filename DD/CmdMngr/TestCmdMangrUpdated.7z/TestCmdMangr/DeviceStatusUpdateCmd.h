#ifndef __DEVICE_STATUS_CMD_H_
#define __DEVICE_STATUS_CMD_H_

#include "AppObj.h"

void InitDeviceStatusUpdateCmd( CmdInfo* pInfo );
void InitGetDeviceStatusCmd( CmdInfo* pInfo );
void InitGetDeviceStateCmd( CmdInfo* pInfo );



#endif //__DEVICE_STATUS_CMD_H_
