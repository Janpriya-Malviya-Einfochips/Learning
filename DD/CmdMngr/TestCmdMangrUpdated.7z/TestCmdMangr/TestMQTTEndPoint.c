
#include "TestMQTTEndPoint.h"


#include "cJSON.h"
#include <stdio.h>
#include <stdint.h>
#include "TestSerialEndPoint.h"
#include "CommandMngr.h"
#include <string.h>
#include <stdlib.h>
#define BUFF_MAX 1024
static  BOOL isTestDone = 0;
static  uint8_t Buffer[BUFF_MAX] = {0};

const char* Cmds[2] =
{
	" { \"cmd_name\" : \"GetStatus\" }",
	" { \"cmd_name\" : \"GetState\" }",
};

BOOL SendToMQTT( void* args , EncodePacket_t encodeCb )
{
	char buffer[1024];
	size_t idx=0;

	if(RESP_OK == encodeCb(args,(uint8_t*)&buffer,&idx))
	{
		char* test = NULL;
		cJSON* rootRsp = cJSON_ParseWithLength(buffer, idx);

		if( !rootRsp )
		{
			printf("Respose Parsing Failed OR INVALID \n");
			return FALSE;
		}

		test = cJSON_Print(rootRsp);
		if(test)
		{
			printf("Final Respose SENT TO MQTT: %s \n",test);
			free(test);
			return TRUE;
		}
		cJSON_Delete(rootRsp);
	}
	else
	{
		printf("failed to encode respose \n");
	}
	return FALSE;
}

static EndPoint_t MQTTEndPoint =
{
	.mType 		= MQTT,
	.mIsEnabled = TRUE,
	.Send       = &SendToMQTT,
};

BOOL IsMQTTTestDone()
{
	return isTestDone;
}

void StartMQTTTest()
{
	isTestDone  = 0;
}


void MQTT_Init()
{
	RegisterEndPoint(&MQTTEndPoint);
}

void ProcMQTTEndPoint()
{
	Cmd  TestCmd;
	if(!isTestDone)
	{
		BOOL isError = FALSE;
		for( int cmdId=0 ; cmdId < 2 ; cmdId++ )
		{
			cJSON* root = cJSON_ParseWithLength(Cmds[cmdId], strlen(Cmds[cmdId]));

			if(!root)
			{
				continue;
			}
			else
			{
				const char* cmdStr = cJSON_GetStringValue(cJSON_GetObjectItem(root,"cmd_name"));

				if( !cmdStr )
				{
					cJSON_Delete(root);
					continue;
				}

				if( !IsValidCommandusingIStr( MQTT , cmdStr , &TestCmd ) ) 
				{
					printf("Command Invalid Test Done \n");
					cJSON_Delete(root);
					continue;
				}

				if(!ParserCommandFromMQTT( root , &TestCmd ))
				{
					printf("Parsing Failed Return \n");
					cJSON_Delete(root);
					continue;
				}

				if( RESP_OK != ProcessCommand(&TestCmd ) )
				{
					printf("Command Failed !! \n");
					isError = TRUE;
				}
				cJSON_Delete(root);
				printf("HandleCommand Done !!! \n");
			}
		}
		isTestDone = !isError;
	}
}
