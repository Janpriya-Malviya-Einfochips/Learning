
#ifndef _CMD_MANGR_H__
#define _CMD_MANGR_H__

#include "AppObj.h"

//Init & Find
void  CommandManagerInit();

//End Point Register / UnRegister APIs
BOOL  RegisterEndPoint(EndPoint_t* endPoint );
BOOL  UnRegisterEndPoint(EndPoint_t* endPoint );


BOOL IsValidCommandusingIChar( EndPointType endPoint , uint8_t iChar , Cmd* pCmd );
BOOL IsValidCommandusingIStr ( EndPointType endPoint , const char* iStr , Cmd* pCmd );
size_t GetCommandLength( Cmd* pCmd );

//Parse command just parser buffer as per command received
BOOL ParseSerialCommand(uint8_t* buffer , size_t length , Cmd* pCmd );
BOOL ParserCommandFromMQTT( cJSON* root , struct Command* Command );
ReturnCode ProcessCommand( Cmd* pCmd );

//Send Respose 
BOOL SendRespose(EndPointType endPoint , void* args , EncodePacket_t encodeCb );

#endif //_CMD_MANGR_H__