

#include <string.h>
#include <stdio.h>
#include "CommandMngr.h"
#include "DeviceStatusUpdateCmd.h"


static CmdInfo CmdTable[CMD_ID_MAX] =
{
	{ .mId = CMD_GET_DEVICE_STATE ,      .Init = &InitGetDeviceStateCmd },
	{ .mId = CMD_GET_DEVICE_STATUS,      .Init = &InitGetDeviceStatusCmd },
	{ .mId = CMD_UPDATE_DEVICE_STATUS ,  .Init = &InitDeviceStatusUpdateCmd },
	{ .mId = CMD_ID_END },
};

//List Of End Points 
static EndPoint_t* sEndPoints[ENDPOINT_END] = { NULL }; 

void  CommandManagerInit()
{
	CmdInfo* pCmdInfo =  &CmdTable[0];
	for( ; pCmdInfo->mId != CMD_ID_END ; ++pCmdInfo )
	{
		pCmdInfo->Init(pCmdInfo);
	}
}

BOOL RegisterEndPoint(EndPoint_t* endPoint )
{
	//Reister End
	if( endPoint && endPoint->mType < ENDPOINT_END )
	{
		if( !sEndPoints[ endPoint->mType ] )
		{
			sEndPoints[ endPoint->mType ] = endPoint;
			return TRUE;
		}
	}
	return FALSE;
}

BOOL  UnRegisterEndPoint(EndPoint_t* endPoint )
{
	//Reister End
	if( endPoint && endPoint->mType < ENDPOINT_END )
	{
		if( sEndPoints[ endPoint->mType ] )
		{
			sEndPoints[ endPoint->mType ] = NULL;
			return TRUE;
		}
	}
	return FALSE;
}

BOOL IsValidCommandusingIChar( EndPointType endPoint , uint8_t iChar , Cmd* pCmd )
{
	CmdInfo* pCmdInfo =  &CmdTable[0];
	for( ; pCmdInfo->mId != CMD_ID_END ; ++pCmdInfo )
	{
		if( iChar == pCmdInfo->mIChar && pCmdInfo->IsValidCmdEndPoint( pCmdInfo->mId , endPoint ) )
		{	
			//Set Command Info 
			pCmd->mInfo = pCmdInfo;
			pCmd->mFrom = endPoint;
			return TRUE; 
		}
	}
	return FALSE; 
}

BOOL IsValidCommandusingIStr ( EndPointType endPoint , const char* iStr , Cmd* pCmd )
{
	CmdInfo* pCmdInfo =  &CmdTable[0];
	for( ; pCmdInfo->mId != CMD_ID_END ; ++pCmdInfo )
	{
		if( ( pCmdInfo->mIString ) && 
		    ( 0 == strcmp( pCmdInfo->mIString , iStr ) ) &&
			( pCmdInfo->IsValidCmdEndPoint( pCmdInfo->mId , endPoint ) ) )
		{	
			//Set Command Info 
			pCmd->mInfo = pCmdInfo;
			pCmd->mFrom = endPoint;
			return TRUE; 
		}
	}
	return FALSE; 
}

size_t GetCommandLength( Cmd* pCmd ) 
{
	return pCmd->mInfo->mLength;
}

BOOL ParseSerialCommand(uint8_t* buffer , size_t length , Cmd* pCmd )
{
	if( pCmd && pCmd->mInfo   )
	{	
		pCmd->mIsParsingDone = TRUE;
		if( pCmd->mInfo->ParserCmdFromSerial )
		{
			return pCmd->mInfo->ParserCmdFromSerial( buffer , length , pCmd );
		}
		else
		{
			size_t cmdLen = GetCommandLength(pCmd);
			printf("Command: %d only supports default parsing !! \n",pCmd->mInfo->mId);
			if(  0 == cmdLen )
			{
				// These Comand have no parametes to pares just a command byte or string
				return TRUE;
			}
			//Command with One byte only
			else if(  1 == cmdLen )
			{
				pCmd->mData.mByte1Param = buffer[0];
				return TRUE;
			}
			//Command with One byte only
			else if( length ==  cmdLen )
			{
				memcpy((void*)&pCmd->mData, (void*)buffer , length );
				return TRUE;
			}
		}
	}
	return FALSE;
}

BOOL ParserCommandFromMQTT( cJSON* root , struct Command* pCmd )
{
	if( pCmd && pCmd->mInfo   )
	{	
		pCmd->mIsParsingDone = TRUE;
		if( pCmd->mInfo->ParserCmdFromMQTT )
		{
			return pCmd->mInfo->ParserCmdFromMQTT( root , pCmd );
		}
		else
		{
			printf("Command: %d only supports default parsing !! \n",pCmd->mInfo->mId);
			if( GetCommandLength(pCmd) == 0 )
			{
				// These Comand have no parametes to pares just a command byte or string
				return TRUE;
			}
		}
	}
	return FALSE;
}

ReturnCode ProcessCommand( Cmd* pCmd )
{
	//NOTE THIS SHOULD BE BASED ON STATE MACHINE !!!
	if( pCmd && pCmd->mInfo && pCmd->mInfo->ProcessCmd )
	{
		return pCmd->mInfo->ProcessCmd( pCmd );
	}
	return PROCSS_ERROR;
}

BOOL SendRespose(EndPointType endPoint , void* args , EncodePacket_t encodeCb )
{
	if( endPoint < ENDPOINT_END )
	{
		if( sEndPoints[ endPoint ] && sEndPoints[ endPoint ]->mIsEnabled )
		{
			return sEndPoints[ endPoint ]->Send(args,encodeCb );
		}
	}
	return FALSE;	
}
