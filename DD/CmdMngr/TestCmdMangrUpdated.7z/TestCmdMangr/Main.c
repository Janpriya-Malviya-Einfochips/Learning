

#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>

#include "TestSerialEndPoint.h"
#include "TestMQTTEndPoint.h"
#include "CommandMngr.h"


int main()
{

	CommandManagerInit();
	Serial_Init();
	MQTT_Init();

	while(1)
	{	

		ProcMQTTEndPoint();
		usleep( 50 * 1000 );
		ProcSerialEndPoint();
		usleep( 50 * 1000 );
	}
	return 0;
}