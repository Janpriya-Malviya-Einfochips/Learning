
#ifndef __APP_OBJ_H__
#define __APP_OBJ_H__
#include <stdint.h>
#include "cJSON.h"

typedef struct deviceStatus 
{
	unsigned int u32CurrentPick;
	unsigned int u32DesignLength;
	unsigned short u16CurrentRepeat;
	unsigned short u16Speed;
	unsigned int u32Second;
	float fCurrentProduction;
	unsigned short u16TotalProduction;
	unsigned char u8TaskNumber;
	unsigned char u8MachineType;
	unsigned short u16TotalRepeat;
	unsigned short u16BorderRepeat;
	unsigned int u32BorderPick;
	unsigned int u32BorderLength;
	char u8FileName1[32];
	char u8FileName2[32];
} DeviceStatus_st;

typedef enum CMD_IDS
{
	CMD_ID_START = 0,
	CMD_GET_DEVICE_STATUS  = CMD_ID_START,			
	CMD_GET_DEVICE_STATE,
	CMD_UPDATE_DEVICE_STATUS,			//From Panel to ESP32 using serial
	//CMD_GET_WIFI_STATUS,
	//CMD_SET_WIFI_STATE,
	//CMD_GET_FILE_ENQ,
	CMD_ID_END,
	CMD_ID_MAX,
}CmdID;

typedef enum RETURN_CODE
{
	NO_RESP,
	PROCSS_ERROR,
	RESP_OK,
	RESP_READY,
	RESP_DELAYED,
}ReturnCode;

typedef enum ENDPOINT_TYPE
{
	ENDPOINT_START = 0,
	SERIAL = ENDPOINT_START,
	MQTT,
	HTTP,
	ENDPOINT_END,
}EndPointType;

typedef enum BOOL_TYPE
{
	FALSE  = 0,
	false  = FALSE,
	TRUE,
	true = TRUE, 
}BOOL;

typedef ReturnCode ( *EncodePacket_t )(void* , uint8_t* , size_t* );

typedef struct EndPointInfo
{
	EndPointType mType;
	BOOL         mIsEnabled;

	//Send Callback !!
	BOOL(*Send)( void* ,EncodePacket_t encodeCb );
}EndPoint_t;

struct Command;
typedef struct Command cmd;

typedef struct CommandInfo
{
	CmdID 	     mId;
	uint8_t  	 mIChar;
	const char*  mIString;
	size_t		 mLength;
	void       (*Init)(struct CommandInfo*);
	BOOL       (*IsValidCmdEndPoint)( CmdID CmdId , EndPointType id );
	BOOL       (*ParserCmdFromSerial)( uint8_t* buffer , size_t length , struct Command* Command );
	BOOL       (*ParserCmdFromMQTT)( cJSON* root , struct Command* Command );
	ReturnCode (*ProcessCmd )(struct Command* Command );
}CmdInfo;

typedef struct Command
{
	CmdInfo* 	 mInfo;
	EndPointType mFrom;		
	BOOL 	     mIsParsingDone;
	void* 		 mPrivate;
	union
	{
		DeviceStatus_st mDeviceStatus;
		uint8_t         mByte1Param;
	}mData;
}Cmd;


void DumpDeviceStatus(DeviceStatus_st* status );

#endif //__APP_OBJ_H__