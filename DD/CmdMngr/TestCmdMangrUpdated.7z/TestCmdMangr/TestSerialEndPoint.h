#ifndef __SREND_OBJ_H__
#define __SREND_OBJ_H__
#include "AppObj.h"


void ProcSerialEndPoint();
void Serial_Init();
BOOL IsSerialTestDone();
void StartSerialTest();

#endif //#define __SREND_OBJ_H__