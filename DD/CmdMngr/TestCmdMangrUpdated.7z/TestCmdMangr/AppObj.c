#include <stdio.h>
#include <string.h>
#include "AppObj.h"


void DumpDeviceStatus(DeviceStatus_st* status )
{
	printf(" DeviceStatus_st \n ");
	printf(" \t   CurrentPick:%d  \n",status->u32CurrentPick);
	printf(" \t  DesignLength:%d  \n",status->u32DesignLength);
	printf(" \t CurrentRepeat:%d  \n",status->u16CurrentRepeat);
	printf(" \t         Speed:%d  \n",status->u16Speed);
	printf(" \t        Second:%d  \n",status->u32Second);
	printf(" \t  CrProduction:%f  \n",status->fCurrentProduction);
	printf(" \t TtlProduction:%d  \n",status->u16TotalProduction);
	printf(" \t  u8TaskNumber:%d  \n",status->u8TaskNumber);
	printf(" \t   MachineType:%d  \n",status->u8MachineType);
	printf(" \t   TotalRepeat:%d  \n",status->u16TotalRepeat);
	printf(" \t  BorderRepeat:%d  \n",status->u16BorderRepeat);
	printf(" \t  BorderLength:%d  \n",status->u32BorderLength);
	printf(" \t    BorderPick:%d  \n",status->u32BorderPick);
	printf(" \t   u8FileName1:%s  \n",status->u8FileName1);
	printf(" \t   u8FileName2:%s  \n",status->u8FileName2);
}
