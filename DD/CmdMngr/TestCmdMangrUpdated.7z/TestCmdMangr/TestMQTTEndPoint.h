#ifndef __MQTT_OBJ_H__
#define __MQTT_OBJ_H__


#include "AppObj.h"

void MQTT_Init();
BOOL IsMQTTTestDone();
void StartMQTTTest();
void ProcMQTTEndPoint();

#endif //#define __MQTT_OBJ_H__