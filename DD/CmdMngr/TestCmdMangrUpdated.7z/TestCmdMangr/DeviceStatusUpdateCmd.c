
#include "DeviceStatusUpdateCmd.h"
#include "CommandMngr.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define DEVICE_STATUS_UPDATE_CMD_ICHAR 'A'
#define GET_DEVICE_STATUS_CMD_ICHAR    'G'
#define GET_DEVICE_STATUS_CMD_ISTR     "GetStatus"
#define GET_DEVICE_STATE_CMD_ISTR      "GetState"

static DeviceStatus_st sDeviceStatus;
static BOOL isDevStatusAvailable = FALSE;

static BOOL IsValidCmdEndPoint( CmdID cId , EndPointType EPointId)
{	
	switch( cId )
	{
	case CMD_UPDATE_DEVICE_STATUS:
		return ( EPointId == SERIAL );

	case CMD_GET_DEVICE_STATE:
	case CMD_GET_DEVICE_STATUS:
		return ( EPointId == MQTT );

	default:
		break;
	}
	return FALSE;
}

static ReturnCode  UpdateDeviceStatus(struct Command* pCmd )
{
	//Just update device status 
	sDeviceStatus = pCmd->mData.mDeviceStatus;
	isDevStatusAvailable = TRUE;
	return NO_RESP;
}

static ReturnCode EncodeRespose( void* args , uint8_t* buffer , size_t* length )
{
	struct Command* pCmd = (struct Command* )(args);
	CmdInfo* pInfo = pCmd->mInfo;

	printf("ENTER  -> %s \n",__func__);
	if( ( ( CMD_GET_DEVICE_STATUS == pInfo->mId )   || 
		  ( CMD_GET_DEVICE_STATE == pInfo->mId  ) ) && 
		  ( pCmd->mFrom == MQTT )
		)
	{
		cJSON* root = cJSON_CreateObject();
		if( root )
		{
			char* pJsonToSerial = NULL;
			DeviceStatus_st* devStatus = (DeviceStatus_st*)pCmd->mPrivate;
			cJSON_AddStringToObject(root, "cmd", pInfo->mIString );

			if( CMD_GET_DEVICE_STATE == pInfo->mId )
			{
				cJSON_AddNumberToObject(root, "device_status", devStatus->u16Speed == 0 ? 1 : 0  );
			}
			else
			{
				//TODO Add Error fild
				//"error": NULL, 						(For Future Use Only)
				cJSON_AddNumberToObject(root, "current_pick", devStatus->u32CurrentPick );
				cJSON_AddNumberToObject(root, "design_length", devStatus->u32DesignLength );
				cJSON_AddNumberToObject(root, "current_repeat", devStatus->u16CurrentRepeat );
				cJSON_AddNumberToObject(root, "speed", devStatus->u16Speed );
				cJSON_AddNumberToObject(root, "second", devStatus->u32Second );
				cJSON_AddNumberToObject(root, "current_production", devStatus->fCurrentProduction );
				cJSON_AddNumberToObject(root, "total_production", devStatus->u16TotalProduction );
				cJSON_AddNumberToObject(root, "task_number", devStatus->u8TaskNumber );
				cJSON_AddNumberToObject(root, "machine_type", devStatus->u8MachineType );
				cJSON_AddNumberToObject(root, "total_repeat", devStatus->u16TotalRepeat );
				cJSON_AddNumberToObject(root, "border_repeat", devStatus->u16BorderRepeat );
				cJSON_AddNumberToObject(root, "border_pick", devStatus->u32BorderPick );
				cJSON_AddNumberToObject(root, "border_length", devStatus->u32BorderLength );
				cJSON_AddStringToObject(root, "fileName1", (char*)devStatus->u8FileName1 );
				cJSON_AddStringToObject(root, "fileName2", (char*)devStatus->u8FileName2 );
			}

			//Convert Serial to JSON Formate !!
			pJsonToSerial = cJSON_Print(root);
			if( pJsonToSerial )
			{	size_t len = strlen(pJsonToSerial);
				memcpy( &buffer[*length] , pJsonToSerial , len );
				*length += len;
				free(pJsonToSerial);
			}
			cJSON_Delete(root);
			printf("EXIT  -> %s \n",__func__);
			return RESP_OK;
		}
	}
	printf("EXIT  -> %s \n",__func__);
	return PROCSS_ERROR;
} 

static ReturnCode  SendDeviceStatus(struct Command* pCmd  )
{	
	printf("ENTER  -> %s \n",__func__);
	if( isDevStatusAvailable )
	{
		//Set Priavate object
		pCmd->mPrivate = (void*)(&sDeviceStatus);
		if( TRUE == SendRespose( pCmd->mFrom , pCmd , &EncodeRespose ))
		{
			return RESP_OK;
		}
	}
	printf("EXIT  -> %s \n",__func__);
	return PROCSS_ERROR;
}

void InitDeviceStatusUpdateCmd( CmdInfo* pInfo )
{	
	//Set Command Info
	printf("ENTER  -> %s \n",__func__);
	pInfo->mIChar    = DEVICE_STATUS_UPDATE_CMD_ICHAR;
	pInfo->mIString  = NULL;
	pInfo->mLength   = sizeof(sDeviceStatus);
	pInfo->IsValidCmdEndPoint = &IsValidCmdEndPoint;
	pInfo->ProcessCmd = &UpdateDeviceStatus;
	printf("EXIT  <- %s \n",__func__);
}

void InitGetDeviceStatusCmd( CmdInfo* pInfo )
{
	printf("ENTER  -> %s \n",__func__);
	pInfo->mIChar    = GET_DEVICE_STATUS_CMD_ICHAR;
	pInfo->mIString  = GET_DEVICE_STATUS_CMD_ISTR;
	pInfo->mLength   = 0;
	pInfo->IsValidCmdEndPoint = &IsValidCmdEndPoint;
	pInfo->ProcessCmd = &SendDeviceStatus;
	printf("EXIT  <- %s \n",__func__);
}

void InitGetDeviceStateCmd( CmdInfo* pInfo )
{
	printf("ENTER  -> %s \n",__func__);
	pInfo->mIChar    = '\0';
	pInfo->mIString  = GET_DEVICE_STATE_CMD_ISTR;
	pInfo->mLength   = 0;
	pInfo->IsValidCmdEndPoint = &IsValidCmdEndPoint;
	pInfo->ProcessCmd = &SendDeviceStatus;
	printf("EXIT  <- %s \n",__func__);
}
